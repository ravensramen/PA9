#pragma once
#include "hazard.h"

class meteorHazard : public hazard
{
public:
	meteorHazard(float startingXPos); //vertical movement from top to bottom
};
